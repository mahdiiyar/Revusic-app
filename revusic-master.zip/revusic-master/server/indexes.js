Posts._ensureIndex({
  body: 'text'
});

Reviews._ensureIndex({
  body: 'text'
});

Meteor.users._ensureIndex({
  username: 'text'
});
